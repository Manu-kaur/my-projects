var fname= document.forms['myForm']['fname'].value;
var lname= document.forms['myForm']['lname'].value;
var email= document.forms['myForm']['email'].value;
var password= document.forms['myForm']['pwd'].value;


function validateForm() {
    
  var fname = document.forms['myForm']['fname'].value;
  if (fname == "") {
    alert("FirstName must be filled out");
    return false;
  }
  var lname = document.forms['myForm']['lname'].value;
  if (lname == "") {
    alert("LastName must be filled out");
    return false;
}
var email = document.forms['myForm']['email'].value;
  if (email == "") {
    alert("Emailid must be filled out");
    return false;
  }
  var password= document.forms['myForm']['pwd'].value;
  if (password == "") {
    alert("Password must be filled out");
    return false;
  }
  else
  {
    alert(" Form Submitted Successfully")
  }
}
var email= document.forms['myForm1']['email'].value;
var password= document.forms['myForm1']['password'].value;
var repeatpassword= document.forms['myForm1']['rpwd'].value;


function validateForm1() {

 var email = document.forms['myForm1']['email'].value;
 if (email == "") {
    alert("Email must be filled out");
   return false;
  }
  var password = document.forms['myForm1']['password'].value;
if (password == "") {
  alert("Password required");
  
  
}
var password = document.forms['myForm1']['password'].value;
if (password <=6) {
  alert("Password should be  8 characters long");
  return false;
  
}
var password = document.forms['myForm1']['password'].value;
if (password >=10 ) {
  alert("Password should not exceed from 10 characters");
  return false;

}
var repeatpassword = document.forms['myForm1']['rpwd'].value;
if (repeatpassword == "") {
  alert(" repeat password should be filled out");
  return false;
}
var repeatpassword = document.forms['myForm1']['rpwd'].value;
if (repeatpassword !== password) {
  alert(" repeatpassword should be same as password");
}
else
  {
    alert(" Form Submitted Successfully")
  }
}
